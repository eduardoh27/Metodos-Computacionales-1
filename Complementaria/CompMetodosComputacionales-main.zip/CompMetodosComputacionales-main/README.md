# CompMetodosComputacionales
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/diegour1/CompMetodosComputacionales/main)

Material del curso Complementaria de Métodos Computacionales 1 de Uniandes 2021 20

> Nota: el material aquí publicado es basado del [proyecto académico de enseñanza de Física Computacional [ComputoCienciasUniandes]](http://computocienciasuniandes.github.io/) liderado por el Profesor Jaime Ernesto Forero

**Universidad de los Andes | Vigilada Mineducación
Reconocimiento como Universidad: Decreto 1297 del 30 de mayo de 1964.
Reconocimiento personería jurídica: Resolución 28 del 23 de febrero de 1949 Minjusticia.**

*Carrera 1 18A-10, Bloque Ip. Bogota - Colombia. A.A. 4976-12340.*   
*Telephone +571 3324500.*
*Fax +571 3324516*

Universidad de los Andes
Facultad de Ciencias
Departamento de Física
